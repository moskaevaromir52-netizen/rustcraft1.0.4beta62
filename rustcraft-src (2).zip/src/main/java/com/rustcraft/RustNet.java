package com.rustcraft;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

/** Сетевой канал мода. Сейчас в нём один пакет: спусковой крючок (ЛКМ нажата / отпущена). */
public final class RustNet {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(RustCraft.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private RustNet() {
    }

    public static void init() {
        CHANNEL.registerMessage(0, TriggerPacket.class,
                TriggerPacket::encode, TriggerPacket::decode, TriggerPacket::handle);
    }

    /** Клиент -> сервер: игрок нажал/отпустил ЛКМ с оружием в руках. */
    public record TriggerPacket(boolean down) {
        public static void encode(TriggerPacket p, FriendlyByteBuf buf) {
            buf.writeBoolean(p.down);
        }

        public static TriggerPacket decode(FriendlyByteBuf buf) {
            return new TriggerPacket(buf.readBoolean());
        }

        public static void handle(TriggerPacket p, Supplier<NetworkEvent.Context> ctx) {
            NetworkEvent.Context c = ctx.get();
            c.enqueueWork(() -> {
                if (c.getSender() != null) GunTrigger.set(c.getSender(), p.down);
            });
            c.setPacketHandled(true);
        }
    }
}
