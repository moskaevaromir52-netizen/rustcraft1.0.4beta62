package com.rustcraft;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Клиентская часть оружия:
 *  - ЛКМ = спусковой крючок (шлём пакет на сервер при нажатии/отпускании);
 *  - ПКМ = прицеливание (ADS), флаг {@link #aiming}, сама механика прицела пока не реализована;
 *  - отдача: при выстреле прицел подбрасывается вверх (и чуть в сторону) плавно, за пару тиков.
 */
@Mod.EventBusSubscriber(modid = RustCraft.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class RecoilClient {
    /** true, пока игрок держит оружие и зажал ПКМ. Сюда потом цепляется прицеливание (зум, поза оружия). */
    public static boolean aiming = false;

    private static long nextShot = 0;
    private static boolean wasDown = false;
    private static boolean triggerSent = false;
    private static float pendingPitch = 0;
    private static float pendingYaw = 0;

    private RecoilClient() {
    }

    /** С оружием в руках ЛКМ не бьёт и не ломает блоки: вместо этого она стреляет. */
    @SubscribeEvent
    public static void onClick(InputEvent.InteractionKeyMappingTriggered e) {
        Minecraft mc = Minecraft.getInstance();
        if (e.isAttack() && mc.player != null && mc.player.getMainHandItem().getItem() instanceof GunItem) {
            e.setSwingHand(false);
            e.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.isPaused()) {
            pendingPitch = 0;
            pendingYaw = 0;
            aiming = false;
            return;
        }

        // плавно отдаём накопленную отдачу
        if (Math.abs(pendingPitch) > 0.01F || Math.abs(pendingYaw) > 0.01F) {
            float dp = pendingPitch * 0.5F;
            float dy = pendingYaw * 0.5F;
            pendingPitch -= dp;
            pendingYaw -= dy;
            p.setXRot(Mth.clamp(p.getXRot() - dp, -90.0F, 90.0F));
            p.setYRot(p.getYRot() + dy);
        }

        ItemStack held = p.getMainHandItem();
        boolean gunInHand = held.getItem() instanceof GunItem;
        boolean inGame = mc.screen == null && mc.mouseHandler.isMouseGrabbed();

        aiming = gunInHand && inGame && mc.options.keyUse.isDown();   // ПКМ: прицел (задел на будущее)

        boolean down = gunInHand && inGame && mc.options.keyAttack.isDown();   // ЛКМ: огонь

        // сообщаем серверу только об изменении состояния крючка
        if (down != triggerSent) {
            RustNet.CHANNEL.sendToServer(new RustNet.TriggerPacket(down));
            triggerSent = down;
        }

        if (down && held.getItem() instanceof GunItem gun) {
            GunItem.Stats s = gun.stats();
            long now = mc.level.getGameTime();
            if ((s.auto() || !wasDown) && now >= nextShot && gun.hasAmmo(p)) {
                nextShot = now + s.delay();
                float r = p.getRandom().nextFloat();
                pendingPitch += s.recoil() * (0.85F + r * 0.3F);
                pendingYaw += (p.getRandom().nextFloat() - 0.5F) * s.recoil() * 0.7F;
            }
        }
        wasDown = down;
    }
}
