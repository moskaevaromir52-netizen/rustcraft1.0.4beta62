package com.rustcraft;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(RustCraft.MODID)
public class RustCraft {
    public static final String MODID = "rustcraft";

    public RustCraft() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEffects.EFFECTS.register(bus);
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModItems.TABS.register(bus);
        RustNet.init();
        MinecraftForge.EVENT_BUS.register(new RustEvents());
    }
}
