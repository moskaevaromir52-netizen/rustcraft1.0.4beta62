package com.rustcraft;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, RustCraft.MODID);

    public static final RegistryObject<Block> SLEEPING_BAG = BLOCKS.register("sleeping_bag",
            () -> new SleepingBagBlock(BlockBehaviour.Properties.of()
                    .strength(0.2F).sound(SoundType.WOOL).noOcclusion().noCollission().forceSolidOff()));

    public static final RegistryObject<Block> TOOL_CUPBOARD = BLOCKS.register("tool_cupboard",
            () -> new ToolCupboardBlock(BlockBehaviour.Properties.of()
                    .strength(3.0F, 6.0F).sound(SoundType.WOOD)));

    // ---- блоки построек (уровни: дерево, камень, металл, бронированный)
    public static final RegistryObject<Block> WOOD_BUILDING = BLOCKS.register("wood_building",
            () -> new BuildingBlock(BlockBehaviour.Properties.of()
                    .strength(6.0F, 12.0F).sound(SoundType.WOOD).noLootTable(), 0));
    public static final RegistryObject<Block> STONE_BUILDING = BLOCKS.register("stone_building",
            () -> new BuildingBlock(BlockBehaviour.Properties.of()
                    .strength(20.0F, 60.0F).sound(SoundType.STONE).noLootTable(), 1));
    public static final RegistryObject<Block> METAL_BUILDING = BLOCKS.register("metal_building",
            () -> new BuildingBlock(BlockBehaviour.Properties.of()
                    .strength(40.0F, 200.0F).sound(SoundType.METAL).noLootTable(), 2));
    public static final RegistryObject<Block> ARMORED_BUILDING = BLOCKS.register("armored_building",
            () -> new BuildingBlock(BlockBehaviour.Properties.of()
                    .strength(80.0F, 600.0F).sound(SoundType.NETHERITE_BLOCK).noLootTable(), 3));

    public static Block building(int tier) {
        return switch (tier) {
            case 0 -> WOOD_BUILDING.get();
            case 1 -> STONE_BUILDING.get();
            case 2 -> METAL_BUILDING.get();
            default -> ARMORED_BUILDING.get();
        };
    }
}
