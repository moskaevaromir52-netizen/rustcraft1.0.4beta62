package com.rustcraft;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.LogicalSide;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Серверная часть стрельбы по ЛКМ. Клиент шлёт TriggerPacket при нажатии/отпускании,
 * а здесь каждый тик вызывается GunItem.pullTrigger(), пока крючок зажат.
 */
@Mod.EventBusSubscriber(modid = RustCraft.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class GunTrigger {
    /** UUID есть в карте - крючок зажат; значение true - это первый тик после нажатия. */
    private static final Map<UUID, Boolean> HELD = new HashMap<>();

    private GunTrigger() {
    }

    public static void set(ServerPlayer p, boolean down) {
        if (down) HELD.putIfAbsent(p.getUUID(), Boolean.TRUE);
        else HELD.remove(p.getUUID());
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != LogicalSide.SERVER) return;
        if (!(e.player instanceof ServerPlayer sp)) return;
        Boolean first = HELD.get(sp.getUUID());
        if (first == null) return;
        ItemStack held = sp.getMainHandItem();
        if (!sp.isAlive() || sp.isSpectator() || !(held.getItem() instanceof GunItem gun)) {
            HELD.remove(sp.getUUID());
            return;
        }
        HELD.put(sp.getUUID(), Boolean.FALSE);
        gun.pullTrigger(sp.serverLevel(), sp, first);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        HELD.remove(e.getEntity().getUUID());
    }

    /** С оружием в руках ЛКМ не ломает блоки и не бьёт врукопашную. */
    @SubscribeEvent
    public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock e) {
        if (e.getEntity().getMainHandItem().getItem() instanceof GunItem) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onAttack(AttackEntityEvent e) {
        if (e.getEntity().getMainHandItem().getItem() instanceof GunItem) e.setCanceled(true);
    }
}
