package com.rustcraft;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/** Блок постройки. 4 уровня: дерево, камень, металл, бронированный. */
public class BuildingBlock extends Block {
    public static final String[] TIER_NAMES = {"Дерево", "Камень", "Металл", "Бронированный"};

    public final int tier;

    public BuildingBlock(Properties props, int tier) {
        super(props);
        this.tier = tier;
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moving) {
        // при улучшении (замена на блок другого уровня) запись о постройке сохраняем
        if (!(newState.getBlock() instanceof BuildingBlock) && level instanceof ServerLevel sl) {
            BuildingData.get(sl).removePos(pos);
        }
        super.onRemove(state, level, pos, newState, moving);
    }
}
