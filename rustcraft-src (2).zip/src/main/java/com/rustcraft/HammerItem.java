package com.rustcraft;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;

import java.util.ArrayList;
import java.util.List;

/**
 * Киянка (Hammer). ПКМ по воздуху - выбрать уровень улучшения (камень/металл/бронированный),
 * ПКМ по постройке - улучшить элемент, Shift+ПКМ по постройке - снести элемент.
 */
public class HammerItem extends SwordItem {

    public HammerItem(Properties props) {
        super(Tiers.IRON, 1, -2.6F, props);
    }

    public static int targetTier(ItemStack stack) {
        int t = stack.hasTag() ? stack.getTag().getInt("tier") : 1;
        return (t < 1 || t > 3) ? 1 : t;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            int t = targetTier(stack) % 3 + 1;
            stack.getOrCreateTag().putInt("tier", t);
            player.displayClientMessage(Component.literal("§6Киянка: улучшение до §f" + BuildingBlock.TIER_NAMES[t]
                    + " §7(материал: " + BuildingPlanner.MATERIAL_NAMES[t] + ")"), true);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        Player p = ctx.getPlayer();
        BlockPos pos = ctx.getClickedPos();
        if (p == null || !(level.getBlockState(pos).getBlock() instanceof BuildingBlock)) {
            return InteractionResult.PASS;
        }
        if (!(level instanceof ServerLevel sl)) return InteractionResult.SUCCESS;

        BuildingData data = BuildingData.get(sl);
        BuildingData.Piece piece = data.at(pos);
        if (piece == null) {
            p.displayClientMessage(Component.literal("§cЭто не элемент постройки"), true);
            return InteractionResult.SUCCESS;
        }
        if (!ClaimData.get(sl).canBuild(pos, p.getUUID())) {
            p.displayClientMessage(Component.literal("§cПриватная территория (Tool Cupboard)"), true);
            return InteractionResult.SUCCESS;
        }

        if (p.isShiftKeyDown()) {
            List<Long> copy = new ArrayList<>(piece.blocks);
            for (long l : copy) {
                sl.setBlock(BlockPos.of(l), Blocks.AIR.defaultBlockState(), 3);
            }
            data.removePiece(piece);
            sl.playSound(null, pos, SoundEvents.WOOD_BREAK, SoundSource.BLOCKS, 1.0F, 0.8F);
            p.displayClientMessage(Component.literal("§eЭлемент снесён"), true);
            return InteractionResult.SUCCESS;
        }

        int target = targetTier(ctx.getItemInHand());
        if (piece.tier >= target) {
            p.displayClientMessage(Component.literal("§cУже " + BuildingBlock.TIER_NAMES[piece.tier]
                    + ". Выберите уровень выше (ПКМ по воздуху)"), true);
            return InteractionResult.SUCCESS;
        }
        BuildingPlanner.Kind kind = BuildingPlanner.Kind.values()[piece.type];
        int units = BuildingPlanner.unitsFor(kind, target);
        boolean creative = p.getAbilities().instabuild;
        if (!creative) {
            int have = BuildingPlanner.count(p, target);
            if (have < units) {
                p.displayClientMessage(Component.literal("§cНужно " + units + " " + BuildingPlanner.MATERIAL_NAMES[target]
                        + " (есть " + have + ")"), true);
                return InteractionResult.SUCCESS;
            }
            BuildingPlanner.take(p, target, units);
        }

        for (long l : piece.blocks) {
            BlockPos b = BlockPos.of(l);
            if (sl.getBlockState(b).getBlock() instanceof BuildingBlock) {
                sl.setBlock(b, ModBlocks.building(target).defaultBlockState(), 3);
            }
        }
        piece.tier = target;
        data.setDirty();
        sl.playSound(null, pos, SoundEvents.ANVIL_USE, SoundSource.BLOCKS, 0.6F, 1.2F);
        p.displayClientMessage(Component.literal("§aУлучшено до: §f" + BuildingBlock.TIER_NAMES[target]), true);
        return InteractionResult.SUCCESS;
    }
}
