package com.rustcraft;

import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.FenceGateBlock;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.List;

public class RustEvents {

    // ---------- Жажда ----------
    public static int getThirst(Player p) {
        CompoundTag t = p.getPersistentData();
        return t.contains("rust_thirst") ? t.getInt("rust_thirst") : 100;
    }

    public static void setThirst(Player p, int v) {
        p.getPersistentData().putInt("rust_thirst", Math.max(0, Math.min(100, v)));
    }

    private static boolean bypass(Player p) {
        return p.isCreative() && p.hasPermissions(2);
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;
        // контур будущей постройки, пока в руке План строительства
        if (p.tickCount % 4 == 0 && p.getMainHandItem().getItem() instanceof BuildingPlanItem) {
            BuildingPlanner.preview(p, BuildingPlanItem.selected(p.getMainHandItem()));
        }
        if (p.isCreative() || p.isSpectator()) return;
        int tick = p.tickCount;

        // пить: присесть в воде
        if (p.isInWater() && p.isShiftKeyDown() && tick % 10 == 0) {
            setThirst(p, getThirst(p) + 2);
        }
        // расход: -1 каждые 5 сек (-2 при беге)
        if (tick % 100 == 0) {
            setThirst(p, getThirst(p) - (p.isSprinting() ? 2 : 1));
        }
        int t = getThirst(p);
        if (t <= 15 && tick % 40 == 0) {
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 0, false, false));
        }
        if (t <= 0 && tick % 40 == 0) {
            p.hurt(p.damageSources().generic(), 1.0F);
        }
        if (tick % 40 == 0) {
            String col = t > 50 ? "§b" : (t > 20 ? "§e" : "§c");
            String bleed = p.hasEffect(ModEffects.BLEEDING.get()) ? "   §4Кровотечение! (нужен бинт)" : "";
            p.displayClientMessage(Component.literal(col + "Жажда: " + t + "%" + bleed), true);
        }
    }

    @SubscribeEvent
    public void onUseFinish(LivingEntityUseItemEvent.Finish e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        ItemStack s = e.getItem();
        if (s.is(Items.POTION) && PotionUtils.getPotion(s) == Potions.WATER) {
            setThirst(p, getThirst(p) + 35);
        } else if (s.is(Items.MELON_SLICE)) {
            setThirst(p, getThirst(p) + 12);
        } else if (s.is(Items.APPLE) || s.is(Items.SWEET_BERRIES)) {
            setThirst(p, getThirst(p) + 6);
        } else if (s.is(Items.MILK_BUCKET)) {
            setThirst(p, getThirst(p) + 25);
        }
    }

    // ---------- Кровотечение ----------
    @SubscribeEvent
    public void onHurt(LivingHurtEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || p.isCreative()) return;
        DamageSource src = e.getSource();
        boolean byMob = src.getEntity() instanceof Monster || src.getDirectEntity() instanceof AbstractArrow;
        boolean hardFall = src.is(DamageTypeTags.IS_FALL) && e.getAmount() >= 6.0F;
        if ((byMob || hardFall) && p.getRandom().nextFloat() < 0.35F) {
            p.addEffect(new MobEffectInstance(ModEffects.BLEEDING.get(), 20 * 20));
            p.displayClientMessage(Component.literal("§4У вас кровотечение!"), true);
        }
    }

    // ---------- Скрап с мобов ----------
    @SubscribeEvent
    public void onDrops(LivingDropsEvent e) {
        LivingEntity le = e.getEntity();
        if (le instanceof Monster && le.getRandom().nextFloat() < 0.25F) {
            e.getDrops().add(new ItemEntity(le.level(), le.getX(), le.getY(), le.getZ(),
                    new ItemStack(ModItems.SCRAP.get(), 1 + le.getRandom().nextInt(2))));
        }
    }

    // ---------- Смерть / спальник ----------
    @SubscribeEvent
    public void onClone(PlayerEvent.Clone e) {
        CompoundTag o = e.getOriginal().getPersistentData();
        CompoundTag n = e.getEntity().getPersistentData();
        if (o.contains("rust_bag")) n.putLong("rust_bag", o.getLong("rust_bag"));
        n.putInt("rust_thirst", e.isWasDeath() ? 100 : (o.contains("rust_thirst") ? o.getInt("rust_thirst") : 100));
    }

    @SubscribeEvent
    public void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || e.isEndConquered()) return;
        CompoundTag d = p.getPersistentData();
        if (!d.contains("rust_bag")) return;
        BlockPos bp = BlockPos.of(d.getLong("rust_bag"));
        ServerLevel ow = p.server.overworld();
        if (ow.getBlockState(bp).getBlock() instanceof SleepingBagBlock) {
            p.teleportTo(ow, bp.getX() + 0.5, bp.getY() + 0.1, bp.getZ() + 0.5, p.getYRot(), p.getXRot());
            p.displayClientMessage(Component.literal("§aВы проснулись в спальнике"), true);
        } else {
            d.remove("rust_bag");
            p.displayClientMessage(Component.literal("§cВаш спальник уничтожен"), true);
        }
    }

    // ---------- Приват (Tool Cupboard) ----------
    @SubscribeEvent
    public void onBreak(BlockEvent.BreakEvent e) {
        if (!(e.getLevel() instanceof ServerLevel lvl) || bypass(e.getPlayer())) return;
        if (!ClaimData.get(lvl).canBuild(e.getPos(), e.getPlayer().getUUID())) {
            e.setCanceled(true);
            e.getPlayer().displayClientMessage(Component.literal("§cПриватная территория (Tool Cupboard)"), true);
        }
    }

    @SubscribeEvent
    public void onPlace(BlockEvent.EntityPlaceEvent e) {
        if (!(e.getEntity() instanceof Player p) || !(e.getLevel() instanceof ServerLevel lvl) || bypass(p)) return;
        if (!ClaimData.get(lvl).canBuild(e.getPos(), p.getUUID())) {
            e.setCanceled(true);
            p.displayClientMessage(Component.literal("§cПриватная территория (Tool Cupboard)"), true);
        }
    }

    @SubscribeEvent
    public void onInteract(PlayerInteractEvent.RightClickBlock e) {
        if (!(e.getLevel() instanceof ServerLevel lvl) || bypass(e.getEntity())) return;
        BlockPos pos = e.getPos();
        Block b = lvl.getBlockState(pos).getBlock();
        if (b instanceof ToolCupboardBlock || b instanceof SleepingBagBlock) return;
        BlockEntity be = lvl.getBlockEntity(pos);
        boolean guarded = be instanceof BaseContainerBlockEntity
                || b instanceof DoorBlock || b instanceof TrapDoorBlock || b instanceof FenceGateBlock;
        if (guarded && !ClaimData.get(lvl).canBuild(pos, e.getEntity().getUUID())) {
            e.setCanceled(true);
            e.setCancellationResult(InteractionResult.FAIL);
            e.getEntity().displayClientMessage(Component.literal("§cЗаперто: чужой приват"), true);
        }
    }

    // ---------- Аирдроп по таймеру (каждые 20 мин) ----------
    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        MinecraftServer s = ServerLifecycleHooks.getCurrentServer();
        if (s == null) return;
        Fuses.tick(s); // таймеры гранат и зарядов
        if (s.getTickCount() % 24000 != 12000) return;
        List<ServerPlayer> players = s.getPlayerList().getPlayers();
        if (players.isEmpty()) return;
        ServerPlayer p = players.get(s.overworld().random.nextInt(players.size()));
        if (p.level().dimension() == Level.OVERWORLD) {
            Airdrop.drop(p.serverLevel(), p.blockPosition());
        }
    }

    @SubscribeEvent
    public void onServerStopped(ServerStoppedEvent e) {
        Fuses.clear();
    }

    // ---------- Команды ----------
    @SubscribeEvent
    public void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("airdrop")
                .requires(src -> src.hasPermission(2))
                .executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    Airdrop.drop(p.serverLevel(), p.blockPosition());
                    return 1;
                }));

        e.getDispatcher().register(Commands.literal("tc")
                .then(Commands.literal("auth")
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(c -> tcAuth(c, true))))
                .then(Commands.literal("deauth")
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(c -> tcAuth(c, false)))));
    }

    private static int tcAuth(CommandContext<CommandSourceStack> c, boolean add) throws CommandSyntaxException {
        ServerPlayer me = c.getSource().getPlayerOrException();
        ServerPlayer target = EntityArgument.getPlayer(c, "player");
        ClaimData data = ClaimData.get(me.serverLevel());
        ClaimData.Claim claim = data.ownedAt(me.blockPosition(), me.getUUID());
        if (claim == null) {
            c.getSource().sendFailure(Component.literal("Вы не владелец шкафа в этой зоне"));
            return 0;
        }
        if (add) claim.auth.add(target.getUUID()); else claim.auth.remove(target.getUUID());
        data.setDirty();
        String name = target.getGameProfile().getName();
        c.getSource().sendSuccess(() -> Component.literal((add ? "Доступ выдан: " : "Доступ отозван: ") + name), false);
        return 1;
    }
}
