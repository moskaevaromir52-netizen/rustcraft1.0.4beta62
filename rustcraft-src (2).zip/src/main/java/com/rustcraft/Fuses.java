package com.rustcraft;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/** Таймеры взрывчатки: брошенный предмет лежит на земле, затем взрывается. */
public final class Fuses {
    private static final class Fuse {
        final ItemEntity entity;
        final ThrowableExplosive.Kind kind;
        final UUID owner;
        int left;

        Fuse(ItemEntity entity, ThrowableExplosive.Kind kind, UUID owner) {
            this.entity = entity;
            this.kind = kind;
            this.owner = owner;
            this.left = kind.fuse;
        }
    }

    private static final List<Fuse> LIST = new ArrayList<>();

    private Fuses() {
    }

    public static void add(ItemEntity e, ThrowableExplosive.Kind kind, UUID owner) {
        LIST.add(new Fuse(e, kind, owner));
    }

    public static void clear() {
        LIST.clear();
    }

    public static void tick(MinecraftServer server) {
        Iterator<Fuse> it = LIST.iterator();
        while (it.hasNext()) {
            Fuse f = it.next();
            if (f.entity.isRemoved() || !(f.entity.level() instanceof ServerLevel level)) {
                it.remove();
                continue;
            }
            f.left--;
            if (f.left > 0) {
                if (f.left % 4 == 0) {
                    Vec3 p = f.entity.position();
                    level.sendParticles(ParticleTypes.SMOKE, p.x, p.y + 0.2, p.z, 1, 0.02, 0.02, 0.02, 0.0);
                }
                continue;
            }
            it.remove();
            detonate(server, level, f);
        }
    }

    private static void detonate(MinecraftServer server, ServerLevel level, Fuse f) {
        Vec3 pos = f.entity.position();
        f.entity.discard();
        Player owner = server.getPlayerList().getPlayer(f.owner);

        if (f.kind == ThrowableExplosive.Kind.MOLOTOV) {
            level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GLASS_BREAK, SoundSource.PLAYERS, 1.0F, 0.8F);
            BlockPos base = BlockPos.containing(pos);
            for (int dx = -3; dx <= 3; dx++) {
                for (int dz = -3; dz <= 3; dz++) {
                    for (int dy = -1; dy <= 2; dy++) {
                        BlockPos bp = base.offset(dx, dy, dz);
                        if (level.random.nextFloat() < 0.6F && level.isEmptyBlock(bp)
                                && level.getBlockState(bp.below()).isFaceSturdy(level, bp.below(), Direction.UP)) {
                            level.setBlockAndUpdate(bp, BaseFireBlock.getState(level, bp));
                        }
                    }
                }
            }
            for (LivingEntity le : level.getEntitiesOfClass(LivingEntity.class, new AABB(base).inflate(4))) {
                le.setSecondsOnFire(8);
                le.hurt(le.damageSources().inFire(), 2.0F);
            }
            level.sendParticles(ParticleTypes.FLAME, pos.x, pos.y + 0.5, pos.z, 40, 1.5, 0.5, 1.5, 0.05);
        } else {
            level.explode(owner, pos.x, pos.y, pos.z, f.kind.power, Level.ExplosionInteraction.TNT);
        }
    }
}
