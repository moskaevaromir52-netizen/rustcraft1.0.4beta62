package com.rustcraft;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** Шкаф (Tool Cupboard): даёт владельцу приват 41x41x41 вокруг себя. */
public class ToolCupboardBlock extends Block {
    public ToolCupboardBlock(Properties props) {
        super(props);
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, LivingEntity placer, ItemStack stack) {
        if (level instanceof ServerLevel sl && placer instanceof Player p) {
            ClaimData.get(sl).add(pos, p.getUUID(), p.getGameProfile().getName());
            p.displayClientMessage(Component.literal("§6Приват установлен. §f/tc auth <игрок> — дать доступ"), true);
        }
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (level instanceof ServerLevel sl) {
            ClaimData.Claim c = ClaimData.get(sl).exact(pos);
            if (c == null) {
                player.displayClientMessage(Component.literal("§cШкаф не активен"), true);
            } else {
                player.sendSystemMessage(Component.literal("§6Tool Cupboard§f: владелец §e" + c.ownerName
                        + "§f, авторизовано: " + c.auth.size()
                        + (c.allows(player.getUUID()) ? " §a(доступ есть)" : " §c(доступа нет)")));
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moving) {
        if (!state.is(newState.getBlock()) && level instanceof ServerLevel sl) {
            ClaimData.get(sl).remove(pos);
        }
        super.onRemove(state, level, pos, newState, moving);
    }
}
